<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package starter
 */

if ( ! is_active_sidebar( 'footer-forth' ) ) {
	return;
}
?>


	
    <?php dynamic_sidebar( 'footer-forth' ); ?>
   

