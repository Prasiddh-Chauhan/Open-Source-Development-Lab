<?php
/**
 * Template Name: Home page
 *
 */
get_header(); ?>

<div class="clear"> </div>
		<div class="content">
			<div class="left-content">
				<div class="searchbar">
					<div class="search-left">
						<p>Latest Video Form VideosTube</p>
					</div>
					<div class="search-right">
						<form role="search" method="get" id="searchform"
    class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div>
        <label class="screen-reader-text" for="s"><?php _x( 'Search for:', 'label' ); ?></label>
        <input type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" />
        <input type="submit" value="" id="searchsubmit" />
    </div>
</form>
					</div>
					<div class="clear"> </div>
				</div>
              
                 <?php 
$wpb_all_query = new WP_Query(array('post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>-1)); ?>
<?php if ( $wpb_all_query->have_posts() ) : ?>
				<div class="box">
                
                <?php $i=0; while ( $wpb_all_query->have_posts() ) : $wpb_all_query->the_post();    $i++;?>
               <?php if($i%3==0){ echo '<div class="grids">';} ?>
				            <?php $content = apply_filters( 'the_content', $post->post_content );
$embeds = get_media_embedded_in_content( $content ); ?>
					<div class="grid">
                   
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                      <?php the_content(); ?>
						<div class="grid-info">
							<div class="video-share">
								<ul>	
									<li><a href="#"><img src="<?php  echo get_template_directory_uri()?>/images/likes.png" title="links" /></a></li>
									<li><a href="#"><img src="<?php echo get_template_directory_uri() ?>/images/link.png" title="Link" /></a></li>
									<li><a href="#"><img src="<?php echo get_template_directory_uri() ?>/images/views.png" title="Views" /></a></li>
								</ul>
							</div>
							<div class="video-watch">
								<a href="single.html">Watch Now</a>
							</div>
							<div class="clear"> </div>
							<div class="lables">
								<p>Labels:<a href="categories.html">Lorem</a></p>
							</div>
						</div>
					</div>
					
					
				 <?php if($i%3==0){ echo '</div>';} ?>
				<div class="clear"> </div>	
                 <?php  endwhile; ?>			
			</div>      
<?php endif; ?>
			<div class="clear"> </div>
			<ul class="dc_pagination dc_paginationA dc_paginationA03">
						  <li><a href="#" class="first">First</a></li>
						  <li><a href="#" class="previous">Previous</a></li>
						  <li><a href="#">1</a></li>
						  <li><a href="#">2</a></li>
						  <li><a href="#" class="current">3</a></li>
						  <li><a href="#">4</a></li>
						  <li><a href="#">5</a></li>
						  <li><a href="#" class="next">Next</a></li>
						  <li><a href="#" class="last">Last</a></li>
						  
						</ul>
			<div class="clear"> </div>
		</div>
		<div class="right-content">
			<div class="popular">
				<h3>Popular Videos</h3>
				<p><img src="<?php echo get_template_directory_uri() ?>/images/l1.png" title="likes" /> 10,000</p>
				<div class="clear"> </div>
			</div>
			<div class="grid1">
						<h3>Consectetur adipisicing elit</h3>
						<a href="#"><img src="<?php echo get_template_directory_uri() ?>/images/g7.jpg" title="video-name" /></a>
						<div class="time1">
							<span>2:50</span>
						</div>
						
						<div class="grid-info">
							<div class="video-share">
								<ul>
									<li><a href="#"><img src="<?php echo get_template_directory_uri() ?>/images/likes.png" title="links" /></a></li>
									<li><a href="#"><img src="<?php echo get_template_directory_uri() ?>/images/link.png" title="Link" /></a></li>
									<li><a href="#"><img src="<?php echo get_template_directory_uri() ?>/images/views.png" title="Views" /></a></li>
								</ul>
							</div>
							<div class="video-watch">
								<a href="#">Watch Now</a>
							</div>
							<div class="clear"> </div>
							<div class="lables">
								<p>Labels:<a href="#">Lorem</a></p>
							</div>
						</div>
					</div>
					<div class="clear"> </div>
					<div class="Recent-Vodeos">
						<h3>Recent-Videos</h3>
						<div class="video1">
							<img src="<?php echo get_template_directory_uri() ?>/images/r1.jpg" title="video2" />
							<span>Lorem ipsum dolor sit amet,</span>
							<p>s consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							<div class="clear"> </div>
						</div>
						<div class="video1 video2">
							<img src="<?php echo get_template_directory_uri() ?>/images/r2.jpg" title="video2" />
							<span>Lorem ipsum dolor sit amet,</span>
							<p>s consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							<div class="clear"> </div>
						</div>
						<div class="r-all">
							<a href="#">View All</a>
						</div>
					</div>
		</div>
		<div class="clear"> </div>
		</div>
		<div class="clear"> </div>
		</div>

       
<?php get_footer(); ?>