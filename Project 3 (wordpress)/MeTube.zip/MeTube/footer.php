<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

		</div><!-- .site-content -->

		<div class="footer">
				<div class="wrap"> 
				<div class="box1">
							 <?php  get_sidebar('footer-first'); ?>
				</div>
				<div class="box1">
				
						 <?php  get_sidebar('footer-second'); ?>
				</div>
				<div class="box1">
				
						 <?php  get_sidebar('footer-third'); ?>
				</div>
				<div class="box1">
								
						 <?php  get_sidebar('footer-forth'); ?>
				</div>
               <div class="box1">
					<div class="hide-box">
				
						 <?php  get_sidebar('footer-fifth'); ?>
				</div>
					</div>
								<div class="clear"> </div>
			</div>
		</div>
	</div><!-- .site-inner -->
</div><!-- .site -->

<?php wp_footer(); ?>
</body>
</html>
